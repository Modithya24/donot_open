#!/bin/bash
echo "Starting Carbon Footprint Tracker Server..."
python3 chatbot.py

